##Requirements Not Yet Met
- Library statistics report not implemented
- Some error messages for requests not accounted for

##Shutdown Functionality
To exit normally enter "/exit"
To run the clean shutdown enter "/shutdown FILE"
To restore persistent state run LBServer with command line arguments "open FILE"
