package Controller.Request;

import Model.Library.LibrarySystem;

/**
 * Gives the system's current date and time.
 * @author Jack Li
 */
public class CurrentDateTime implements Request {

    /**
     * Singleton timekeeper to keep time the same across the system.
     */
    private LibrarySystem library;

    /**
     * Creates a new CurrentDateTime command.
     */
    public CurrentDateTime(LibrarySystem library) {
        this.library = library;
    }

    /**
     * Checks whether the parameters are valid for this command.
     * @return Nothing, since this command does not require parameters.
     */
    @Override
    public String checkParams() {
        return "";
    }

    /**
     * Executes the CurrentDateTime command to return the current date and time.
     * @return The current date and time within the system.
     */
    @Override
    public String execute() {
        return library.currentDateTime();
    }
}
