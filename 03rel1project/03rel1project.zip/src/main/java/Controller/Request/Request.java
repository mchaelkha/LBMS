package Controller.Request;

public interface Request extends RequestUtil {
    String checkParams();
    String execute();
}
